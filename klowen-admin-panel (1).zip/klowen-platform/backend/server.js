/**
 * Serveur principal — Klowen-Bot Platform API
 */
require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const { Server } = require('socket.io');

const { connectDB } = require('./config/db');
const { logError } = require('./utils/logger');
const adminRoutes = require('./routes/admin');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.FRONTEND_URL, credentials: true } });
app.set('io', io);

// Sécurité de base
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use(cookieParser());

// Limite de requêtes globale (anti brute-force / abus)
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

// Routes
app.use('/api/admin', adminRoutes);

app.get('/api/status', (req, res) => res.json({ status: 'ok', time: new Date() }));

// Gestion centralisée des erreurs
app.use((err, req, res, next) => {
  logError(err.stack || err.message);
  res.status(500).json({ error: 'Erreur interne du serveur.' });
});

const PORT = process.env.PORT || 4000;

(async () => {
  await connectDB();
  server.listen(PORT, () => console.log(`🚀 API Klowen Platform sur le port ${PORT}`));
})();
