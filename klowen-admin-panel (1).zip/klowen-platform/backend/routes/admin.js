/**
 * Routes du panneau d'administration
 * Toutes les routes ci-dessous exigent : auth + adminOnly
 */
const express = require('express');
const router = express.Router();

const auth = require('../middleware/auth');
const adminOnly = require('../middleware/adminOnly');
const User = require('../models/User');
const Bot = require('../models/Bot');
const Announcement = require('../models/Announcement');
const { readRecentLogs, readRecentErrors } = require('../utils/logger');

router.use(auth, adminOnly);

/* ============================
 * UTILISATEURS
 * ============================ */

// Liste de tous les utilisateurs
router.get('/users', async (req, res) => {
  const users = await User.find().select('-passwordHash').sort({ createdAt: -1 });
  res.json(users);
});

// Suspendre un utilisateur
router.patch('/users/:id/suspend', async (req, res) => {
  const user = await User.findByIdAndUpdate(
    req.params.id,
    { status: 'suspended' },
    { new: true }
  ).select('-passwordHash');
  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  res.json(user);
});

// Réactiver un utilisateur
router.patch('/users/:id/reactivate', async (req, res) => {
  const user = await User.findByIdAndUpdate(
    req.params.id,
    { status: 'active' },
    { new: true }
  ).select('-passwordHash');
  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  res.json(user);
});

// Supprimer un utilisateur (et ses bots associés)
router.delete('/users/:id', async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  await Bot.deleteMany({ owner: req.params.id });
  res.json({ success: true });
});

/* ============================
 * BOTS
 * ============================ */

// Liste de tous les bots déployés sur la plateforme, avec leur propriétaire
router.get('/bots', async (req, res) => {
  const bots = await Bot.find().populate('owner', 'username email').sort({ createdAt: -1 });
  res.json(bots);
});

// Détail d'un bot (ressources incluses)
router.get('/bots/:id', async (req, res) => {
  const bot = await Bot.findById(req.params.id).populate('owner', 'username email');
  if (!bot) return res.status(404).json({ error: 'Bot introuvable.' });
  res.json(bot);
});

/* ============================
 * STATISTIQUES GLOBALES
 * ============================ */

router.get('/stats', async (req, res) => {
  const [totalUsers, activeUsers, suspendedUsers, totalBots, runningBots] = await Promise.all([
    User.countDocuments(),
    User.countDocuments({ status: 'active' }),
    User.countDocuments({ status: 'suspended' }),
    Bot.countDocuments(),
    Bot.countDocuments({ status: 'running' }),
  ]);

  const resourceAgg = await Bot.aggregate([
    {
      $group: {
        _id: null,
        totalCpu: { $sum: '$resources.cpuPercent' },
        totalRam: { $sum: '$resources.ramMB' },
        totalDisk: { $sum: '$resources.diskMB' },
      },
    },
  ]);

  res.json({
    totalUsers,
    activeUsers,
    suspendedUsers,
    totalBots,
    runningBots,
    resources: resourceAgg[0] || { totalCpu: 0, totalRam: 0, totalDisk: 0 },
  });
});

/* ============================
 * ANNONCES
 * ============================ */

// Créer et diffuser une annonce à tous les utilisateurs
router.post('/announcements', async (req, res) => {
  const { title, message, severity } = req.body;
  if (!title || !message) {
    return res.status(400).json({ error: 'Titre et message requis.' });
  }
  const announcement = await Announcement.create({
    title,
    message,
    severity: severity || 'info',
    createdBy: req.user._id,
  });

  // Diffusion en temps réel via Socket.io (si disponible)
  const io = req.app.get('io');
  if (io) io.emit('announcement', announcement);

  res.status(201).json(announcement);
});

// Liste des annonces (les plus récentes en premier)
router.get('/announcements', async (req, res) => {
  const announcements = await Announcement.find().sort({ createdAt: -1 }).limit(50);
  res.json(announcements);
});

/* ============================
 * LOGS & ERREURS
 * ============================ */

router.get('/logs', async (req, res) => {
  const lines = await readRecentLogs(200);
  res.json({ lines });
});

router.get('/logs/errors', async (req, res) => {
  const lines = await readRecentErrors(200);
  res.json({ lines });
});

module.exports = router;
