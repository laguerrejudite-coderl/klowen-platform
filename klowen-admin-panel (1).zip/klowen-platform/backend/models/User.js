/**
 * Modèle Utilisateur
 * Représente un compte de la plateforme (client ou administrateur)
 */
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    username: { type: String, required: true, unique: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },

    role: { type: String, enum: ['user', 'admin'], default: 'user' },

    // Statut du compte (utilisé par le panneau admin)
    status: { type: String, enum: ['active', 'suspended'], default: 'active' },

    // Nombre de bots que l'utilisateur a le droit de déployer
    botQuota: { type: Number, default: 1 },

    lastLoginAt: { type: Date },
    createdAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
