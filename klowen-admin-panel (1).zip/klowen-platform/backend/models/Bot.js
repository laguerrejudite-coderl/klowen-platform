/**
 * Modèle Bot
 * Représente une instance déployée de Klowen-Bot pour un utilisateur donné.
 * Chaque bot correspond à un conteneur Docker isolé.
 */
const mongoose = require('mongoose');

const botSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

    name: { type: String, required: true, default: 'Klowen-Bot' },

    // Identifiant du conteneur Docker associé à ce bot
    containerId: { type: String },
    containerName: { type: String },

    // Statut d'exécution du conteneur
    status: {
      type: String,
      enum: ['running', 'stopped', 'restarting', 'error', 'deploying'],
      default: 'deploying',
    },

    // Méthode de connexion WhatsApp utilisée
    connectionMethod: { type: String, enum: ['qr', 'pairing'], default: 'qr' },

    // Métriques ressources (mises à jour périodiquement par le worker de supervision)
    resources: {
      cpuPercent: { type: Number, default: 0 },
      ramMB: { type: Number, default: 0 },
      diskMB: { type: Number, default: 0 },
      uptimeSeconds: { type: Number, default: 0 },
    },

    lastError: { type: String },
    lastRestartAt: { type: Date },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Bot', botSchema);
