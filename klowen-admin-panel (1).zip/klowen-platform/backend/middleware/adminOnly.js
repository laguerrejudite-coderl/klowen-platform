/**
 * Middleware admin
 * À utiliser après `auth` : bloque l'accès si l'utilisateur n'est pas administrateur.
 */
function adminOnly(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Accès réservé aux administrateurs.' });
  }
  next();
}

module.exports = adminOnly;
