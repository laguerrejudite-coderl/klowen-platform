/**
 * Utilitaire de journalisation
 * Écrit les logs applicatifs et permet de relire les dernières lignes
 * pour les afficher dans le panneau admin.
 */
const fs = require('fs');
const path = require('path');
const pino = require('pino');

const LOG_DIR = path.join(process.cwd(), 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const LOG_FILE = path.join(LOG_DIR, 'app.log');
const ERROR_FILE = path.join(LOG_DIR, 'error.log');

const logger = pino(
  { level: 'info' },
  pino.destination({ dest: LOG_FILE, sync: false })
);

function logError(message) {
  fs.appendFile(ERROR_FILE, `[${new Date().toISOString()}] ${message}\n`, () => {});
}

async function readLastLines(filePath, count) {
  if (!fs.existsSync(filePath)) return [];
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n').filter(Boolean);
  return lines.slice(-count);
}

async function readRecentLogs(count = 200) {
  return readLastLines(LOG_FILE, count);
}

async function readRecentErrors(count = 200) {
  return readLastLines(ERROR_FILE, count);
}

module.exports = { logger, logError, readRecentLogs, readRecentErrors };
