/**
 * Client API — appelle le backend Express en incluant le cookie JWT.
 */
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

async function request(path: string, options: RequestInit = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Erreur API (${res.status})`);
  }
  return res.json();
}

export const api = {
  get: (path: string) => request(path),
  patch: (path: string, data?: unknown) =>
    request(path, { method: 'PATCH', body: data ? JSON.stringify(data) : undefined }),
  post: (path: string, data?: unknown) =>
    request(path, { method: 'POST', body: data ? JSON.stringify(data) : undefined }),
  del: (path: string) => request(path, { method: 'DELETE' }),
};
