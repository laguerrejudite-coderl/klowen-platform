'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const links = [
  { href: '/admin', label: 'Vue d\u2019ensemble' },
  { href: '/admin/users', label: 'Utilisateurs' },
  { href: '/admin/bots', label: 'Bots' },
  { href: '/admin/announcements', label: 'Annonces' },
  { href: '/admin/logs', label: 'Journaux' },
];

export default function AdminSidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-60 shrink-0 border-r border-neutral-800 bg-neutral-950 min-h-screen p-4">
      <div className="mb-8 px-2">
        <p className="text-sm font-semibold tracking-tight text-white">Klowen-Bot</p>
        <p className="text-xs text-neutral-500">Panneau administrateur</p>
      </div>
      <nav className="space-y-1">
        {links.map((link) => {
          const active = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`block rounded-md px-3 py-2 text-sm transition-colors ${
                active
                  ? 'bg-orange-600/15 text-orange-400'
                  : 'text-neutral-400 hover:bg-neutral-900 hover:text-neutral-200'
              }`}
            >
              {link.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
