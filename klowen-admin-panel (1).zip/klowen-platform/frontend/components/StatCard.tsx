export default function StatCard({
  label,
  value,
  accent = false,
}: {
  label: string;
  value: string | number;
  accent?: boolean;
}) {
  return (
    <div className="rounded-lg border border-neutral-800 bg-neutral-900 p-5">
      <p className="text-xs uppercase tracking-wide text-neutral-500">{label}</p>
      <p
        className={`mt-2 text-2xl font-semibold ${
          accent ? 'text-orange-400' : 'text-white'
        }`}
      >
        {value}
      </p>
    </div>
  );
}
