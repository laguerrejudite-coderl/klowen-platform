import AdminSidebar from '@/components/AdminSidebar';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex bg-neutral-950 text-neutral-100">
      <AdminSidebar />
      <main className="flex-1 p-8">{children}</main>
    </div>
  );
}
