'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

type User = {
  _id: string;
  username: string;
  email: string;
  role: 'user' | 'admin';
  status: 'active' | 'suspended';
  createdAt: string;
};

export default function AdminUsers() {
  const [users, setUsers] = useState<User[]>([]);
  const [error, setError] = useState('');

  const load = () => api.get('/api/admin/users').then(setUsers).catch((e) => setError(e.message));

  useEffect(() => {
    load();
  }, []);

  async function toggleStatus(user: User) {
    const action = user.status === 'active' ? 'suspend' : 'reactivate';
    await api.patch(`/api/admin/users/${user._id}/${action}`);
    load();
  }

  async function removeUser(user: User) {
    if (!confirm(`Supprimer définitivement ${user.username} et ses bots ?`)) return;
    await api.del(`/api/admin/users/${user._id}`);
    load();
  }

  return (
    <div>
      <h1 className="text-xl font-semibold text-white">Utilisateurs</h1>
      <p className="mt-1 text-sm text-neutral-500">{users.length} compte(s) enregistré(s).</p>

      {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

      <div className="mt-6 overflow-hidden rounded-lg border border-neutral-800">
        <table className="w-full text-left text-sm">
          <thead className="bg-neutral-900 text-neutral-400">
            <tr>
              <th className="px-4 py-3 font-medium">Nom d&apos;utilisateur</th>
              <th className="px-4 py-3 font-medium">Email</th>
              <th className="px-4 py-3 font-medium">Rôle</th>
              <th className="px-4 py-3 font-medium">Statut</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800">
            {users.map((u) => (
              <tr key={u._id} className="text-neutral-200">
                <td className="px-4 py-3">{u.username}</td>
                <td className="px-4 py-3 text-neutral-400">{u.email}</td>
                <td className="px-4 py-3">{u.role}</td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2 py-1 text-xs ${
                      u.status === 'active'
                        ? 'bg-green-500/15 text-green-400'
                        : 'bg-red-500/15 text-red-400'
                    }`}
                  >
                    {u.status === 'active' ? 'Actif' : 'Suspendu'}
                  </span>
                </td>
                <td className="px-4 py-3 text-right space-x-2">
                  <button
                    onClick={() => toggleStatus(u)}
                    className="rounded-md border border-neutral-700 px-3 py-1 text-xs hover:bg-neutral-800"
                  >
                    {u.status === 'active' ? 'Suspendre' : 'Réactiver'}
                  </button>
                  <button
                    onClick={() => removeUser(u)}
                    className="rounded-md border border-red-900 px-3 py-1 text-xs text-red-400 hover:bg-red-950"
                  >
                    Supprimer
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
