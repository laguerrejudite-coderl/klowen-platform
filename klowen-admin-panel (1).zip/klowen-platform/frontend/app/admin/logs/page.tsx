'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

export default function AdminLogs() {
  const [tab, setTab] = useState<'logs' | 'errors'>('logs');
  const [lines, setLines] = useState<string[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const path = tab === 'logs' ? '/api/admin/logs' : '/api/admin/logs/errors';
    api
      .get(path)
      .then((r) => setLines(r.lines))
      .catch((e) => setError(e.message));
  }, [tab]);

  return (
    <div>
      <h1 className="text-xl font-semibold text-white">Journaux</h1>
      <p className="mt-1 text-sm text-neutral-500">Dernières lignes des journaux serveur.</p>

      <div className="mt-4 flex gap-2">
        <button
          onClick={() => setTab('logs')}
          className={`rounded-md px-3 py-1 text-sm ${
            tab === 'logs' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:bg-neutral-800'
          }`}
        >
          Logs généraux
        </button>
        <button
          onClick={() => setTab('errors')}
          className={`rounded-md px-3 py-1 text-sm ${
            tab === 'errors' ? 'bg-orange-600 text-white' : 'text-neutral-400 hover:bg-neutral-800'
          }`}
        >
          Erreurs
        </button>
      </div>

      {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

      <pre className="mt-4 max-h-[60vh] overflow-auto rounded-lg border border-neutral-800 bg-black p-4 text-xs text-neutral-300">
        {lines.length ? lines.join('\n') : 'Aucune entrée.'}
      </pre>
    </div>
  );
}
