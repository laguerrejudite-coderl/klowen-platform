'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

type Announcement = {
  _id: string;
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'critical';
  createdAt: string;
};

export default function AdminAnnouncements() {
  const [list, setList] = useState<Announcement[]>([]);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [severity, setSeverity] = useState<'info' | 'warning' | 'critical'>('info');
  const [error, setError] = useState('');

  const load = () => api.get('/api/admin/announcements').then(setList).catch((e) => setError(e.message));

  useEffect(() => {
    load();
  }, []);

  async function send() {
    if (!title || !message) return;
    await api.post('/api/admin/announcements', { title, message, severity });
    setTitle('');
    setMessage('');
    setSeverity('info');
    load();
  }

  return (
    <div>
      <h1 className="text-xl font-semibold text-white">Annonces</h1>
      <p className="mt-1 text-sm text-neutral-500">
        Diffusez un message à tous les utilisateurs connectés en temps réel.
      </p>

      {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

      <div className="mt-6 max-w-lg space-y-3 rounded-lg border border-neutral-800 bg-neutral-900 p-5">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Titre"
          className="w-full rounded-md border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-white"
        />
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Message"
          rows={3}
          className="w-full rounded-md border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-white"
        />
        <select
          value={severity}
          onChange={(e) => setSeverity(e.target.value as typeof severity)}
          className="w-full rounded-md border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-white"
        >
          <option value="info">Information</option>
          <option value="warning">Avertissement</option>
          <option value="critical">Critique</option>
        </select>
        <button
          onClick={send}
          className="rounded-md bg-orange-600 px-4 py-2 text-sm font-medium text-white hover:bg-orange-500"
        >
          Diffuser l&apos;annonce
        </button>
      </div>

      <div className="mt-8 space-y-3">
        {list.map((a) => (
          <div key={a._id} className="rounded-lg border border-neutral-800 bg-neutral-900 p-4">
            <div className="flex items-center justify-between">
              <p className="font-medium text-white">{a.title}</p>
              <span className="text-xs text-neutral-500">
                {new Date(a.createdAt).toLocaleString('fr-FR')}
              </span>
            </div>
            <p className="mt-1 text-sm text-neutral-400">{a.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
