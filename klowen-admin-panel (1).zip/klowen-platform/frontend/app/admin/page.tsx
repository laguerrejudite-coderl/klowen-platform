'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import StatCard from '@/components/StatCard';

type Stats = {
  totalUsers: number;
  activeUsers: number;
  suspendedUsers: number;
  totalBots: number;
  runningBots: number;
  resources: { totalCpu: number; totalRam: number; totalDisk: number };
};

export default function AdminOverview() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .get('/api/admin/stats')
      .then(setStats)
      .catch((e) => setError(e.message));
  }, []);

  return (
    <div>
      <h1 className="text-xl font-semibold text-white">Vue d&apos;ensemble</h1>
      <p className="mt-1 text-sm text-neutral-500">
        État global de la plateforme en temps réel.
      </p>

      {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

      {stats && (
        <>
          <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3">
            <StatCard label="Utilisateurs" value={stats.totalUsers} />
            <StatCard label="Comptes actifs" value={stats.activeUsers} />
            <StatCard label="Comptes suspendus" value={stats.suspendedUsers} />
            <StatCard label="Bots déployés" value={stats.totalBots} />
            <StatCard label="Bots en ligne" value={stats.runningBots} accent />
            <StatCard label="RAM totale (MB)" value={Math.round(stats.resources.totalRam)} />
          </div>
        </>
      )}
    </div>
  );
}
