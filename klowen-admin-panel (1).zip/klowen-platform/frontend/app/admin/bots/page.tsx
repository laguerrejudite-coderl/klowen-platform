'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

type Bot = {
  _id: string;
  name: string;
  status: string;
  owner: { username: string; email: string };
  resources: { cpuPercent: number; ramMB: number; diskMB: number; uptimeSeconds: number };
};

const statusColor: Record<string, string> = {
  running: 'bg-green-500/15 text-green-400',
  stopped: 'bg-neutral-500/15 text-neutral-400',
  restarting: 'bg-yellow-500/15 text-yellow-400',
  error: 'bg-red-500/15 text-red-400',
  deploying: 'bg-blue-500/15 text-blue-400',
};

export default function AdminBots() {
  const [bots, setBots] = useState<Bot[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/api/admin/bots').then(setBots).catch((e) => setError(e.message));
  }, []);

  return (
    <div>
      <h1 className="text-xl font-semibold text-white">Bots déployés</h1>
      <p className="mt-1 text-sm text-neutral-500">{bots.length} instance(s) sur la plateforme.</p>

      {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

      <div className="mt-6 overflow-hidden rounded-lg border border-neutral-800">
        <table className="w-full text-left text-sm">
          <thead className="bg-neutral-900 text-neutral-400">
            <tr>
              <th className="px-4 py-3 font-medium">Bot</th>
              <th className="px-4 py-3 font-medium">Propriétaire</th>
              <th className="px-4 py-3 font-medium">Statut</th>
              <th className="px-4 py-3 font-medium">CPU</th>
              <th className="px-4 py-3 font-medium">RAM</th>
              <th className="px-4 py-3 font-medium">Disque</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800">
            {bots.map((b) => (
              <tr key={b._id} className="text-neutral-200">
                <td className="px-4 py-3">{b.name}</td>
                <td className="px-4 py-3 text-neutral-400">{b.owner?.username}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2 py-1 text-xs ${statusColor[b.status]}`}>
                    {b.status}
                  </span>
                </td>
                <td className="px-4 py-3">{b.resources.cpuPercent}%</td>
                <td className="px-4 py-3">{b.resources.ramMB} MB</td>
                <td className="px-4 py-3">{b.resources.diskMB} MB</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
