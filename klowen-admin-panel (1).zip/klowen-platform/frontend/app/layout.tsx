import './globals.css';

export const metadata = {
  title: 'Klowen-Bot — Plateforme',
  description: 'Plateforme d\u2019hébergement pour Klowen-Bot',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
